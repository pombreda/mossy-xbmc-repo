#/bin/python
# -*- coding: utf-8 -*-

import os
#import xbmcplugin
#import xbmcgui
import re
import geturllib
#import fourOD_token_decoder
#import mycgi
import urllib
import urlparse

showTitle = "8 Out of 10 Cats"
showId = "8-out-of-10-cats"

#parts=(scheme='file', netloc='', path='/home/mossy/html.html', params='', query='', fragment='')
#parts=(scheme='file', path='/home/mossy/html.html')
#print urlparse.urlunparse((scheme='file', netloc='', path='/home/mossy/html.html', params='', query='', fragment=''))
print urlparse.urlunparse(('file', '', '/home/mossy/html.html', '', '', ''))
#print urlparse.urlparse('file:///home/mossy/html.html')
print "pathname2url: " + urllib.pathname2url("/home/mossy")
geturllib.SetCacheDir("/home/mossy")
print "Looking for episodes for: " + showTitle
print "URL: " + "http://www.channel4.com/programmes/" + showId + "/4od"
#html = geturllib.GetURL( "http://www.channel4.com/programmes/" + showId$
html = geturllib.GetURL( "file:///home/mossy/html.html" )
print "do showsInfo..."
#showsInfo = re.findall( '<li.*?<a class=".*?" href="/programmes/(.*?)/4od".*?<image src="(.*?)".*?<p class="title">(.*?)</p>.*?<p class="synopsis">(.*?)</p>', html, re.DOTALL )
showsInfo = re.findall( '<li.*?<a class=".*?" href="/programmes/(.*?)/4od".*?<img src="(.*?)".*?<p class="title">(.*?)</p>.*?<p class="synopsis">(.*?)</p>', html, re.DOTALL )
print "done!"
system.exit()
if ( len ( str(html) ) < 30000 ):
        print "Invalid html"
#        html = geturllib.GetURL( "http://www.channel4.com/programmes/"
#        if ( len ( str(html) ) < 30000 ):
#                print "Invalid html again"
#        return

print "Continue"

ol = re.search( '<ol class="all-series">(.*?)</div>', html, re.DOTALL ).groups()[0]

print "Findall..."
epsInfo = re.findall( '<li.*?data-episode-number="(.*?)".*?data-assetid="(.*?)".*?data-episodeUrl="(.*?)".*?data-image-url="(.*?)".*?data-episodeTitle="(.*?)".*?data-episodeInfo="(.*?)".*?data-episodeSynopsis="(.*?)".*?data-series-number="(.*?)"', ol, re.DOTALL )


print "Epsinfo count: " + len(epsinfo)

listItems = []
for epInfo in epsInfo:
        epNum = epInfo[0]
        seriesNum = epInfo[7]
        if ( seriesNum <> "" and epNum <> "" ):
                fn = showId + ".s%0.2ie%0.2i" % (int(seriesNum),int(epNum))

        else:
                fn = showId
        id = epInfo[1]
        print "FOUND id: " + id
        img = epInfo[3]
        progTitle = epInfo[4].strip()
        progTitle = progTitle.replace( '&amp;', '&' )
        epTitle = epInfo[5].strip()
        if ( progTitle == showTitle and epTitle <> "" ):
                label = epTitle
        else:
                label = progTitle
        url = "http://www.channel4.com" + epInfo[2]
        description = remove_extra_spaces(remove_html_tags(epInfo[6]))
        description = description.replace( '&amp;', '&' )
        description = description.replace( '&pound;', '�' )
        if (img == ""):
                thumbnail = re.search( '<meta property="og:image" content="(.*?)"', html, re.DOTALL ).groups()[0]

        else:
                thumbnail = "http://www.channel4.com" + img

        newListItem = xbmcgui.ListItem( label )
        newListItem.setThumbnailImage(thumbnail)
        newListItem.setInfo('video', {'Title': label, 'Plot': description, 'PlotOutline': description})

        url = gBaseURL + '?ep=' + mycgi.URLEscape(id) + "&title=" + mycgi.URLEscape(label) + "&fn=" + mycgi.URLEscape(fn)

        listItems.append( (url,newListItem,False) )

