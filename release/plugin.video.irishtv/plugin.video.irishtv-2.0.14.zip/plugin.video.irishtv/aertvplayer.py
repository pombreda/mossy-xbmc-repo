from player import BasePlayer

class AerTVPlayer(BasePlayer):
    def onPlayBackSeek(self, time, seekOffset):        
        pass

    def onPlayBackSeekChapter(self, chapter):
        pass        

    def onPlayBackSpeedChanged(self,speed):
        pass
